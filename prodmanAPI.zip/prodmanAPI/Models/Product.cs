﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace prodmanAPI.Models
{
    public class Product
    {
        [Key,DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int id { get; set; }
        [StringLength(50)]
        public string name { get; set; }
        public int catalogId { get; set; }
        public int price { get; set; }
        public string productAttributes { get; set; } //CreateExample: XL;Black;Unisex;MyBrand -> Final Product: Size=XL;Color=Black;Gender=Unisex;Brand=MyBrand
    }
}
