﻿using Microsoft.AspNetCore.Mvc;
using prodmanAPI.Fake;
using prodmanAPI.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace prodmanAPI.Controllers
{
    [Route("api/[controller]")]
    public class ProductsController:ControllerBase
    {
        /// <summary>
        /// GetProducts
        /// </summary>
        /// <returns></returns>
        [HttpGet]
        public List<Product> GetProducts()
        {
            using (var productDbContext = new Context())
            {
                return productDbContext.products.ToList();
            }
        }

        /// <summary>
        /// GetProductById
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        [HttpGet("{id}")]
        public Product GetProductById(int id)
        {
            using (var productDbContext = new Context())
            {
                return productDbContext.products.Find(id);
            }
        }

        /// <summary>
        /// GetProductsByAttr
        /// </summary>
        /// <param name="attr_name"></param>
        /// <param name="attr_value"></param>
        /// <returns></returns>
        [HttpGet("{attr_name},{attr_value}")]
        public List<Product> GetProductsByAttr(string attr_name, string attr_value)
        {
            var products = new List<Product>();
            using (var proructDbContext = new Context())
            {
                foreach (var prd in proructDbContext.products.ToList())
                {
                    var attr_list = prd.productAttributes.Split(";");
                    foreach(var attr in attr_list)
                    {
                        var cur_attr_name = attr.Split("=")[0];
                        var cur_attr_value = attr.Split("=")[1];
                        if (cur_attr_name.ToLower() == attr_name.ToLower() && cur_attr_value.ToLower() == attr_value.ToLower()) { products.Add(prd); }
                    }
                }
            }
            return products;
        }

        /// <summary>
        /// CreateProduct
        /// </summary>
        /// <param name="product"></param>
        /// <returns></returns>
        [HttpPost]
        public Product CreateProduct([FromBody]Product product)
        {
            using (var productDbContext = new Context())
            {
                productDbContext.products.Add(product);
                productDbContext.SaveChanges();
                return product;
            }
        }

        /// <summary>
        /// UpdateProduct
        /// </summary>
        /// <param name="product"></param>
        /// <returns></returns>
        [HttpPut]
        public Product UpdateProduct([FromBody] Product product)
        {
            using (var productDbContext = new Context())
            {
                productDbContext.products.Update(product);
                productDbContext.SaveChanges();
                return product;
            }
        }

        /// <summary>
        /// DeleteProductById
        /// </summary>
        /// <param name="id"></param>
        [HttpDelete("{id}")]
        public void DeleteProductById(int id)
        {
            using (var productDbContext = new Context())
            {
                var target_product = GetProductById(id);
                productDbContext.products.Remove(target_product);
                productDbContext.SaveChanges();
            }
        }
    }
}
