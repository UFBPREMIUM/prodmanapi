﻿using Microsoft.AspNetCore.Mvc;
using prodmanAPI.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace prodmanAPI.Controllers
{
    [Route("api/[controller]")]
    public class ProductCategoriesController:ControllerBase
    {
        /// <summary>
        /// GetCategories
        /// </summary>
        /// <returns>A list of categories</returns>
        [HttpGet]
        public List<ProductCategory> GetCategories()
        {
            using (var categoryDbContext = new Context())
            {
                return categoryDbContext.productCategories.ToList();
            }
        }

        /// <summary>
        /// GetProductsFromCategory
        /// </summary>
        /// <param name="catalog_id"></param>
        /// <returns></returns>
        [HttpGet("{catalog_id}")]
        public List<Product> GetProductsFromCategory(int catalog_id)
        {
            var products_in_category = new List<Product>();
            using (var proructDbContext = new Context())
            {
                foreach(var prd in proructDbContext.products.ToList())
                {
                    if (prd.catalogId == catalog_id) { products_in_category.Add(prd); }    
                }
            }
            return products_in_category;
        }

        /// <summary>
        /// GetProductFromCategoryById
        /// </summary>
        /// <param name="catalog_id"></param>
        /// <param name="product_id"></param>
        /// <returns></returns>
        [HttpGet("{catalog_id},{product_id}")]
        public Product GetProductFromCategoryById(int catalog_id, int product_id)
        {
            using (var proructDbContext = new Context())
            {
                foreach (var prd in proructDbContext.products.ToList())
                {
                    if (prd.catalogId == catalog_id && prd.id == product_id) { return prd; }
                }
            }
            return new Product();
        }

        /// <summary>
        /// GetCategoryById
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        [HttpGet("{id}")]
        public ProductCategory GetCategoryById(int id)
        {
            using (var categoryDbContext = new Context())
            {
                return categoryDbContext.productCategories.Find(id);
            }
        }

        /// <summary>
        /// CreateCategory
        /// </summary>
        /// <param name="productCategory"></param>
        /// <returns></returns>
        [HttpPost]
        public ProductCategory CreateCategory([FromBody] ProductCategory productCategory)
        {
            using (var categoryDbContext = new Context())
            {
                categoryDbContext.productCategories.Add(productCategory);
                categoryDbContext.SaveChanges();
                return productCategory;
            }
        }

        /// <summary>
        /// AddProductToCategory
        /// </summary>
        /// <param name="catalog_id"></param>
        /// <returns></returns>
        [HttpPost("{catalog_id}")]
        public Product AddProductToCategory(int catalog_id, Product product)
        {
            using (var categoryDbContext = new Context())
            {
                var target_category = GetCategoryById(catalog_id);
                var attr_list = target_category.categoryAttributes.Split(";");
                using (var productDbContext = new Context())
                {
                    product.catalogId = catalog_id;
                    var attr_values = product.productAttributes.Split(";");
                    string product_attributes = "";
                    for (int i=0; i < attr_list.Length; i++)
                    {
                        product_attributes += attr_list[i] + "=" + attr_values[i] + ";";
                    }
                    product_attributes = product_attributes.Remove(product_attributes.Length - 1);
                    product.productAttributes = product_attributes;
                    productDbContext.products.Add(product);
                    productDbContext.SaveChanges();
                    return product;
                }
            }
        }

        /// <summary>
        /// UpdateCategory
        /// </summary>
        /// <param name="productCategory"></param>
        /// <returns></returns>
        [HttpPut]
        public ProductCategory UpdateCategory([FromBody] ProductCategory productCategory)
        {
            using (var categoryDbContext = new Context())
            {
                categoryDbContext.productCategories.Update(productCategory);
                categoryDbContext.SaveChanges();
                return productCategory;
            }
        }

        /// <summary>
        /// DeleteCategoryById - Also delete all products in category
        /// </summary>
        /// <param name="id"></param>
        [HttpDelete("{id}")]
        public void DeleteCategoryById(int id)
        {
            using (var categoryDbContext = new Context())
            {
                var target_category = GetCategoryById(id);
                categoryDbContext.productCategories.Remove(target_category);
                using (var productDbContext = new Context())
                {
                    foreach (var prd in productDbContext.products.ToList())
                    {
                        if (prd.catalogId == id) { productDbContext.products.Remove(prd); }
                    }
                    productDbContext.SaveChanges();
                }
                categoryDbContext.SaveChanges();
            }
        }
    }
}
