﻿using Bogus;
using prodmanAPI.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace prodmanAPI.Fake
{
    public static class FakeData
    {
        private static List<Product> _products;

        public static List<Product> TestCreateFakeProducts(int count)
        {
            if (_products == null)
            {
                _products = new Faker<Product>()
                    .RuleFor(p => p.id, f => f.IndexFaker)
                    .RuleFor(p => p.catalogId, f => f.IndexVariable)
                    .RuleFor(p => p.name, f => f.Lorem.Word())
                    .RuleFor(p => p.price, f => f.IndexGlobal)
                    .Generate(count);
            }
            return _products;
        }
    }
}
